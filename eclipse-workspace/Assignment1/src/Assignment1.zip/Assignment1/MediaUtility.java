package Assignment1;


/*MediaUtility interface
 * Joseph Fuguet and Josh Labrie
 * 
 */

public interface MediaUtility {
String print(); //Methods present in all Media types
double getCost();
}
